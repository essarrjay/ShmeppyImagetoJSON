# set import paths
import __init__
import shmeppify

if __name__ == '__main__':
    shmeppify.main()
