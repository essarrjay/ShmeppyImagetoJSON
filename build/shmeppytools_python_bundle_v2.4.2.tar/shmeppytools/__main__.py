import imageconverter

if __name__ == '__main__':
    imageconverter.shmeppify.main()
