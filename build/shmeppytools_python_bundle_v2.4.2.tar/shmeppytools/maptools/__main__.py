# set import paths
import __init__
import combinemaps
if __name__ == '__main__':
    combinemaps.main()
